var urlBase = "http://localhost/Impiccato/";
//console.log(urlBase);
const immaginiImpiccato = ["url(IMG/imgStruttura.png)","url(IMG/imgCappio.png)","url(IMG/imgTesta.png)","url(IMG/imgCorpo.png)","url(IMG/imgBraccio.png)","url(IMG/imgBracci.png)","url(IMG/imgGamba.png)","url(IMG/imgFinale.png)" ];

//VARIABILI GLOBALI
let ParoleContenitore = document.querySelector(".parola");
let ImpiccatoContenitore = document.querySelector(".impiccato");
let MsgContenitore = document.querySelector(".message");
let contenitoreLettere = document.querySelector(".letters");
let nErrori = 0;
let parolaVis = "";

//pagina in carica
window.onload = function() {
//Richiedo parola random da lista parole file
const ric2 = document.getElementById("richiesta");
ric2.addEventListener("click", parolaRandom);
parolaRandom();

};

//Mi collego al server per estrarre la parola da utilizzare di quelle del FILE
async function parolaRandom() {
  try {
    const contenitoreLettere = document.querySelector(".letters");
    contenitoreLettere.innerHTML = "";
      let risposta = await fetch(urlBase + 'Server/serverFile.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
      });

      let data = await risposta.json();
      console.log('Risposta dal server:', data);

      if (data.success) {
          startGame(data.parola);
      } else {
          console.error('Errore durante il recupero dei dati:', data.message);
      }
  } catch (error) {
      console.error('Errore durante il recupero dei dati:', error);
  }
}

function startGame(parola) {
  //Imposta la parola da indovinare
  const parolaNascosta = parola.toLowerCase();
  const spazi =  document.querySelector(".parola").textContent = "_ ".repeat(parolaNascosta.length).trim();
 
  //Pulisce gli oggetti esistenti dal contenitore delle lettere
  ParoleContenitore.innerHTML = "";
  //Crea gli spazi vuoti nella variabile ParoleContenitore
  for (let i = 0; i < spazi.length; i++) {
    const space = document.createElement("span");
    space.textContent = spazi[i];
    ParoleContenitore.appendChild(space);
  }

  //Imposta la variabile parolaVisualizzata
  parolaVis = spazi;

//Reimposto le immagini dell'impiccato a
ImpiccatoContenitore.style.backgroundImage = immaginiImpiccato[0];

// Crea le l'alfabeto
const lettereAlfabeto = "abcdefghijklmnopqrstuvwxyz";
//vado a ripulire ContenitoreLettere
contenitoreLettere.innerHTML = ""; //Contenitore lettere contienetutte le lettere
//vado a creare i bottoni per il gioco
for (let i = 0; i < lettereAlfabeto.length; i++) {
  const bottoneConLettera = document.createElement("button");
  const letteraCorrente = lettereAlfabeto[i]; // Crea una copia della lettera corrente
  bottoneConLettera.setAttribute("data-letter", letteraCorrente);
  bottoneConLettera.textContent = letteraCorrente;
  bottoneConLettera.addEventListener("click", function() {
    controllaLettera(parolaNascosta, letteraCorrente);
  });
  contenitoreLettere.appendChild(bottoneConLettera);
}
  //ripulisco messaggio vinto/perso
  MsgContenitore.textContent = "";
}

function controllaLettera(parola, lettera) {
  //disabilito la lettera cliccata in modo da non poterla usare più
  const bottoneConLettera = document.querySelector(`.letters button[data-letter="${lettera}"]`);
  bottoneConLettera.disabled = true;

  //Controlla se la lettera è presente nella parola
  const parolaNascosta = parola.toLowerCase();
  const posLettera = [];
  for (let i = 0; i < parolaNascosta.length; i++) {
    if (parolaNascosta[i] === lettera) {
      posLettera.push(i);
    }
  }

  //Visualizzo la lettera se indovinata
  if (posLettera.length > 0) {
    posLettera.forEach(indice => {
      const indiceEffettivo = indice * 2; //Moltiplica per 2 a causa dello spazio tra le lettere
    const elementoLettera = ParoleContenitore.children[indiceEffettivo];
    elementoLettera.textContent = lettera;
      

      //Aggiorna la parola visualizzata sottol'impiccato
      const lettereVis = Array.from(ParoleContenitore.children)
        .map(letteraElement => letteraElement.textContent.trim())//trim viene utilizzato per rimuove eventuali spazi vuoti all'inizio e alla fine della parola. 
        .join(" ");
      parolaVis = lettereVis;
       console.log(parolaVis);
      
      //Verifica se hai indovinato tutte le lettere controllandose ci sono ancora "_"
      if (!parolaVis.includes('_')) {
        MsgContenitore.textContent = "Congratulazioni, Hai vinto!";
        disabilitaTastiera();
      }
    });
  } else {
    //Aggiorna l'immagine dell'impiccato
    nErrori++;
    ImpiccatoContenitore.style.backgroundImage = immaginiImpiccato[nErrori];
    console.log("Numero Errori: ",nErrori);
    console.log('Nuova immagine:', immaginiImpiccato[nErrori]);

    //Verifica se il gioco è terminato
    if (nErrori === immaginiImpiccato.length - 1) {
      MsgContenitore.textContent = "Mi dispiace Hai perso! La parola era: " + parola;
      disabilitaTastiera();
    }
  }
}

//Disabilito i bottoni rendendoli non  più utilizzabili
  function disabilitaTastiera() {
  const letterButtons = document.querySelectorAll(".letters button");
  letterButtons.forEach(button => (button.disabled = true));
}
