<?php

 header("Access-Control-Allow-Origin: *");

 $jObj = null;
 //Collegamento al db
 $indirizzoServerDBMS = "localhost";
 $nomeDb = "impiccato";
 $conn = mysqli_connect($indirizzoServerDBMS, "root", "", $nomeDb);
 if($conn->connect_errno>0){
     $jObj = preparaRisp(-1, "Connessione rifiutata");
 }else{
     $jObj = preparaRisp(0, "Connessione ok");
 }

$sql = "SELECT parola FROM parolefile ORDER BY RAND() LIMIT 1";//Query per scegliere random una parola
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $pRandom = $row["parola"];
    $risposta = array(
        "success" => true,
        "parola" => $pRandom
    );
    echo json_encode($risposta);
} else {
    $risposta = array(
        "success" => false,
        "message" => "Nessuna parola trovata nella tabella."
    );
    echo json_encode($risposta);
}

// Chiudo connessione DB
$conn->close();

function preparaRisp($cod, $desc, $jObj = null){
    if(is_null($jObj)){
        $jObj = new stdClass();
    }
    $jObj->cod = $cod;
    $jObj->desc = $desc;
    return $jObj;
}
?>