<?php

 header("Access-Control-Allow-Origin: *");

 $jObj = null;
 //Collegamento al db
 $indirizzoServerDBMS = "localhost";
 $nomeDb = "impiccato";
 $conn = mysqli_connect($indirizzoServerDBMS, "root", "", $nomeDb);
 if($conn->connect_errno>0){
     $jObj = preparaRisp(-1, "Connessione rifiutata");
 }else{
     $jObj = preparaRisp(0, "Connessione ok");
 }

//prendo la parola scritta dall'  utente e la inserisco nel DB
if (isset($_POST['parolaUtente'])) {
    $parolaUt = $_POST['parolaUtente'];
    $sql = "INSERT INTO parole (parola) VALUES ('$parolaUt')";//  Query per l'inserimento
    if ($conn->query($sql) === TRUE) {
        echo "Parola inserita con successo!";
    } else {
        echo "Errore durante l'inserimento della parola: " . $conn->error;
    }
}
    
/**************************************************************************************************************************************************************************/

//Inserimento del file 
$filePath = "../60000_parole_italiane.txt"; //Percorso File
$fileContents = file_get_contents($filePath);
$vetParole = explode("\n", $fileContents);

foreach ($vetParole as $parola) {
    $parola = $conn->real_escape_string(trim($parola));  //real_escape_string è una funzione che tratta i caratteri speciali in modo da renderli utilizzabili in SQL 
    $sql = "INSERT INTO parolefile (parola) VALUES ('$parola')";

    if ($conn->query($sql) !== TRUE) { //Mi indica  che c'è un errore qua prof
        echo "Errore durante l'inserimento della parola: " . $conn->error;
    }
}
echo "  File inserito con successo!";

//Chiudo connesione DB
$conn->close();

 function preparaRisp($cod, $desc, $jObj = null){
    if(is_null($jObj)){
        $jObj = new stdClass();
    }
    $jObj->cod = $cod;
    $jObj->desc = $desc;
    return $jObj;
}
?>


